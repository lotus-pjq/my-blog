(function () {
  const quickLinksRoot = document.getElementById("quickLinks");
  const postsGrid = document.getElementById("postsGrid");
  const projectsGrid = document.getElementById("projectsGrid");
  const menuToggle = document.getElementById("menuToggle");
  const siteNav = document.getElementById("siteNav");

  if (quickLinksRoot) {
    siteData.quickLinks.forEach((item) => {
      const a = document.createElement("a");
      a.className = "quick-link";
      a.href = item.href;
      a.textContent = item.label;
      if (item.href.startsWith("http")) {
        a.target = "_blank";
        a.rel = "noreferrer";
      }
      quickLinksRoot.appendChild(a);
    });
  }

  if (postsGrid) {
    siteData.posts.forEach((post) => {
      const article = document.createElement("article");
      article.className = "post-card";
      article.innerHTML = `
        <div class="post-topline">
          <span>${post.tag}</span>
          <span>${post.date}</span>
        </div>
        <div class="post-meta">
          <span>${post.category}</span>
          <span>${post.readTime}</span>
        </div>
        <h3>${post.title}</h3>
        <p>${post.excerpt}</p>
        <span class="post-readmore">继续阅读 →</span>
      `;
      postsGrid.appendChild(article);
    });
  }

  if (projectsGrid) {
    siteData.projects.forEach((project) => {
      const article = document.createElement("article");
      article.className = "project-card";
      article.innerHTML = `
        <h3>${project.name}</h3>
        <p>${project.desc}</p>
        <div class="project-stack">${project.stack}</div>
      `;
      projectsGrid.appendChild(article);
    });
  }

  if (menuToggle && siteNav) {
    menuToggle.addEventListener("click", () => {
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => siteNav.classList.remove("is-open"));
    });
  }
})();
