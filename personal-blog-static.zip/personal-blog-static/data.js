const siteData = {
  quickLinks: [
    { label: "GitHub", href: "https://github.com/" },
    { label: "Email", href: "mailto:your-email@example.com" },
    { label: "Blog RSS", href: "#" },
  ],
  posts: [
    {
      title: "算法竞赛中的结构化思维",
      date: "2026-03-01",
      tag: "Algorithm",
      category: "题解方法",
      readTime: "8 min",
      excerpt: "从笛卡尔树到状态搜索，记录我在竞赛题中如何把直觉整理成可复用的方法。",
    },
    {
      title: "连续时间电池 SOC 建模笔记",
      date: "2026-02-24",
      tag: "Modeling",
      category: "研究笔记",
      readTime: "11 min",
      excerpt: "整理二阶 RC、KiBaM 与温度修正项如何组合成一个可落地的智能手机电池模型。",
    },
    {
      title: "把个人博客做得更像作品集",
      date: "2026-02-17",
      tag: "Design",
      category: "设计记录",
      readTime: "6 min",
      excerpt: "在不过度花哨的前提下，让技术博客也能保留一点轻二次元与个人表达。",
    },
  ],
  projects: [
    {
      name: "Battery SOC Research",
      desc: "连续时间 SOC 建模与温度修正实验整理。",
      stack: "Python / Modeling / Papers",
    },
    {
      name: "Competitive Programming Notes",
      desc: "算法题解、构造思路与数据生成经验总结。",
      stack: "C++ / Graph / DP / Data Structure",
    },
    {
      name: "Creative Blog Design",
      desc: "带有轻二次元气质的个人博客视觉探索。",
      stack: "Static Site / CSS / Vibe Coding",
    },
  ],
};
