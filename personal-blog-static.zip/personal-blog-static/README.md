# Personal Blog Static Starter

这是一个低维护、可直接上传到 GitHub Pages 的静态个人博客起始版本。

## 文件说明

- `index.html`：页面结构
- `styles.css`：全局样式
- `data.js`：文章、项目、快捷链接的数据源
- `script.js`：把 `data.js` 渲染到页面上
- `assets/wallpaper.jpg`：首页壁纸

## 本地预览

最简单的方法：直接双击 `index.html` 打开。

更推荐的方法：用 VS Code 的 Live Server，或者任何本地静态服务器预览。

## 你后续最常改的地方

### 改首页文案
打开 `index.html`

### 改配色、间距、卡片样式
打开 `styles.css`

### 改文章和项目内容
打开 `data.js`

### 换首页壁纸
替换 `assets/wallpaper.jpg`

## 上传到 GitHub Pages

1. 新建一个 GitHub 仓库。
2. 把这个文件夹里的所有文件上传到仓库根目录。
3. 打开仓库 `Settings -> Pages`。
4. 在 `Build and deployment` 里选择：
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/(root)`
5. 保存后等待几十秒到几分钟。
6. 打开生成的网址即可。

## 推荐的仓库命名

### 最省事
仓库名：`你的用户名.github.io`

这样网址会是：

`https://你的用户名.github.io/`

### 普通仓库名
如果仓库叫 `my-blog`，网址一般会是：

`https://你的用户名.github.io/my-blog/`

## 为什么这版更适合你现在接手

- 没有构建步骤
- 不需要 `npm install`
- GitHub Pages 直接可用
- 结构清晰，适合继续交给 vibecoding 扩展
- 以后想升级到 React / Vue 再迁移也不晚
